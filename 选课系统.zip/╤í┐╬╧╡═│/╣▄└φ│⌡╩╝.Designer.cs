﻿namespace 教务系统
{
    partial class Form8
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.课程ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.开设课程ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.修改学生信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.修改学生信息ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.添加学生信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.教师信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.修改教师信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.添加教师ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.表ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.删除ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.课程ToolStripMenuItem,
            this.修改学生信息ToolStripMenuItem,
            this.教师信息ToolStripMenuItem,
            this.表ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(729, 25);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 课程ToolStripMenuItem
            // 
            this.课程ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.开设课程ToolStripMenuItem});
            this.课程ToolStripMenuItem.Name = "课程ToolStripMenuItem";
            this.课程ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.课程ToolStripMenuItem.Text = "课程信息";
            // 
            // 开设课程ToolStripMenuItem
            // 
            this.开设课程ToolStripMenuItem.Name = "开设课程ToolStripMenuItem";
            this.开设课程ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.开设课程ToolStripMenuItem.Text = "开设课程";
            this.开设课程ToolStripMenuItem.Click += new System.EventHandler(this.开设课程ToolStripMenuItem_Click);
            // 
            // 修改学生信息ToolStripMenuItem
            // 
            this.修改学生信息ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.修改学生信息ToolStripMenuItem1,
            this.添加学生信息ToolStripMenuItem});
            this.修改学生信息ToolStripMenuItem.Name = "修改学生信息ToolStripMenuItem";
            this.修改学生信息ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.修改学生信息ToolStripMenuItem.Text = "学生信息";
            // 
            // 修改学生信息ToolStripMenuItem1
            // 
            this.修改学生信息ToolStripMenuItem1.Name = "修改学生信息ToolStripMenuItem1";
            this.修改学生信息ToolStripMenuItem1.Size = new System.Drawing.Size(148, 22);
            this.修改学生信息ToolStripMenuItem1.Text = "修改学生信息";
            // 
            // 添加学生信息ToolStripMenuItem
            // 
            this.添加学生信息ToolStripMenuItem.Name = "添加学生信息ToolStripMenuItem";
            this.添加学生信息ToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.添加学生信息ToolStripMenuItem.Text = "添加学生";
            // 
            // 教师信息ToolStripMenuItem
            // 
            this.教师信息ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.修改教师信息ToolStripMenuItem,
            this.添加教师ToolStripMenuItem});
            this.教师信息ToolStripMenuItem.Name = "教师信息ToolStripMenuItem";
            this.教师信息ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.教师信息ToolStripMenuItem.Text = "教师信息";
            // 
            // 修改教师信息ToolStripMenuItem
            // 
            this.修改教师信息ToolStripMenuItem.Name = "修改教师信息ToolStripMenuItem";
            this.修改教师信息ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.修改教师信息ToolStripMenuItem.Text = "修改教师信息";
            // 
            // 添加教师ToolStripMenuItem
            // 
            this.添加教师ToolStripMenuItem.Name = "添加教师ToolStripMenuItem";
            this.添加教师ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.添加教师ToolStripMenuItem.Text = "添加教师";
            // 
            // 表ToolStripMenuItem
            // 
            this.表ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.删除ToolStripMenuItem});
            this.表ToolStripMenuItem.Name = "表ToolStripMenuItem";
            this.表ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.表ToolStripMenuItem.Text = "表格信息";
            // 
            // 删除ToolStripMenuItem
            // 
            this.删除ToolStripMenuItem.Name = "删除ToolStripMenuItem";
            this.删除ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.删除ToolStripMenuItem.Text = "删除操作";
            this.删除ToolStripMenuItem.Click += new System.EventHandler(this.删除ToolStripMenuItem_Click);
            // 
            // Form8
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(729, 491);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form8";
            this.Text = "Form8";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 课程ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 开设课程ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 修改学生信息ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 修改学生信息ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 添加学生信息ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 教师信息ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 修改教师信息ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 添加教师ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 表ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 删除ToolStripMenuItem;
    }
}